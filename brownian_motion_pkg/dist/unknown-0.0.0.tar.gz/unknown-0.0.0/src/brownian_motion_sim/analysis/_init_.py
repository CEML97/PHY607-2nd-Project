# src/brownian_motion_sim/analysis/__init__.py
from .error_analysis import SimulationResults

__all__ = ['SimulationResults']

